__version__ = '0.5.0'
git_version = 'a86f483198d8e6cb3608513156e1562570ef31c2'
